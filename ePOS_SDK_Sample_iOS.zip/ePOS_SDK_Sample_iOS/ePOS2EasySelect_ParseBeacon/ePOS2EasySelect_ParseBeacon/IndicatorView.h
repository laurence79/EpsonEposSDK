#import <UIKit/UIKit.h>

@interface IndicatorView : UIView

- (void)show:(UIView*)base;
- (void)hide;

@end
