
#import <UIKit/UIKit.h>

@interface RSSIBarView : UIView

- (void) setDrawInfo:(BOOL)enable rssiLevel:(NSInteger)rssiLevel;

@end
