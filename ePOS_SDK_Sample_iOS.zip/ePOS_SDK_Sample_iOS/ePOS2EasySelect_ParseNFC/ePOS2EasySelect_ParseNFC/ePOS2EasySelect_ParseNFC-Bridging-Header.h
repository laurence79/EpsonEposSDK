#ifndef ePOS2EasySelect_ParseNFC_Bridging_Header_h
#define ePOS2EasySelect_ParseNFC_Bridging_Header_h

#import "ePOS2.h"
#import "ePOSEasySelect.h"

#endif /* ePOS2EasySelect_ParseNFC_Bridging_Header_h */
