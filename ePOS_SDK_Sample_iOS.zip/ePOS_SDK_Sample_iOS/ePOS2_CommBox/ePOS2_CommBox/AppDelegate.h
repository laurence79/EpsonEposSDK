//
//  AppDelegate.h
//  ePOS2_CommBox
//
//  Created by admin on 2015/07/13.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
