#import "LineDisplayViewController.h"
#import "ShowMsg.h"

#define KEY_RESULT                  @"Result"
#define KEY_METHOD                  @"Method"
#define BLINK_INTERVAL              1000

@interface LineDisplayViewController() <Epos2DispReceiveDelegate>
@end

@implementation LineDisplayViewController

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        lineDisplay_ = nil;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    [self setDoneToolbar];
}

- (void)setDoneToolbar
{
    UIToolbar *doneToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
    doneToolbar.barStyle = UIBarStyleBlackTranslucent;

    [doneToolbar sizeToFit];
    UIBarButtonItem *space = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneKeyboard:)];

    NSMutableArray *items = [NSMutableArray arrayWithObjects:space, doneButton, nil];
    [doneToolbar setItems:items animated:YES];
    _textTarget.inputAccessoryView = doneToolbar;
    _textData.inputAccessoryView = doneToolbar;
}

- (void)doneKeyboard:(id)sender
{
    [_textTarget resignFirstResponder];
    [_textData resignFirstResponder];
}

- (IBAction)textDisplay:(id)sender
{
    [self updateButtonState:NO];
    if (![self runLineDisplaySequence]) {
        [self updateButtonState:YES];
    }
}

- (BOOL)runLineDisplaySequence
{
    int result = EPOS2_SUCCESS;

    if (![self initializeObject]) {
        return NO;
    }

    if (![self createDisplayData]) {
        [self finalizeObject];
        return NO;
    }

    if (![self connectDisplay]) {
        [self finalizeObject];
        return NO;
    }

    result = [lineDisplay_  sendData];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"sendData"];
        [self disconnectDisplay];
        return NO;
    }

    return YES;
}

- (void)updateButtonState:(BOOL)state
{
    _buttonDisplay.enabled = state;
}

- (BOOL)createDisplayData
{
    int result = EPOS2_SUCCESS;

    if (lineDisplay_ == nil) {
        return NO;
    }

    result = [lineDisplay_ addInitialize];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"addInitialize"];
        return NO;
    }

    result = [lineDisplay_ addSetCursorPosition:1 y:1];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"addSetCursorPosition"];
        return NO;
    }

    if (_switchBlink.on) {
        result = [lineDisplay_ addSetBlink:BLINK_INTERVAL];
        if (result != EPOS2_SUCCESS) {
            [ShowMsg showErrorEpos:result method:@"addSetBlink"];
            return NO;
        }
    }

    result = [lineDisplay_ addText:_textData.text];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"addText"];
        return NO;
    }

    return YES;
}

- (BOOL)initializeObject
{

    lineDisplay_ = [[Epos2LineDisplay alloc]initWithDisplayModel:EPOS2_DM_D30];

    if (lineDisplay_ == nil) {
        [ShowMsg showErrorEpos:EPOS2_ERR_MEMORY method:@"initWithDisplayModel"];
        return NO;
    }

    [lineDisplay_ setReceiveEventDelegate:self];

    return YES;
}

- (void)finalizeObject
{
    if (lineDisplay_ == nil) {
        return;
    }

    [lineDisplay_ clearCommandBuffer];

    [lineDisplay_ setReceiveEventDelegate:nil];

    lineDisplay_ = nil;
}

- (BOOL)connectDisplay
{
    int result = EPOS2_SUCCESS;

    if (lineDisplay_ == nil) {
        return NO;
    }

    result = [lineDisplay_ connect:_textTarget.text timeout:EPOS2_PARAM_DEFAULT];
    if (result != EPOS2_SUCCESS) {
        [ShowMsg showErrorEpos:result method:@"connect"];
        [self finalizeObject];
        return NO;
    }

    return YES;
}

- (void)disconnectDisplay
{
    int result = EPOS2_SUCCESS;

    if (lineDisplay_ == nil) {
        return;
    }

    result = [lineDisplay_ disconnect];
    if (result != EPOS2_SUCCESS) {
        NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
        [dict setObject:[NSNumber numberWithInt:result] forKey:KEY_RESULT];
        [dict setObject:@"disconnect" forKey:KEY_METHOD];

        [self performSelectorOnMainThread:@selector(showEposErrorFromThread:) withObject:dict waitUntilDone:NO];
    }

    [self finalizeObject];
}

- (void)showEposErrorFromThread:(NSDictionary *)dict
{
    int result = EPOS2_SUCCESS;
    NSString *method = @"";
    result = [[dict valueForKey:KEY_RESULT] intValue];
    method = [dict valueForKey:KEY_METHOD];
    [ShowMsg showErrorEpos:result method:method];
}

- (void) onDispReceive:(Epos2LineDisplay *)displayObj code:(int)code
{
    [ShowMsg showResult:code];

    [self updateButtonState:YES];

    [self performSelectorInBackground:@selector(disconnectDisplay) withObject:nil];
}
@end
